#!/bin/sh
./syscall.sh &
./syscall.sh &
./syscall.sh &
./syscall.sh &
./syscall.sh &
wait
