#!/bin/sh
time ../pgms/pipe
echo "pipe completed"
echo "---"
